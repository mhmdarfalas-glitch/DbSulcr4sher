module.exports = {
  TELEGRAM_TOKEN: `8607164796:AAGbjlVhhVUtLkwDXPeb-SrMlOTm1lkrmos`,
  TELEGRAM_ID: `7902328386`,

  GITHUB_TOKEN: `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`,
  GITHUB_OWNER: `Sulcr4sherV3-design`,
  GITHUB_REPO: `gh repo clone mhmdarfalas-glitch/DbSulcr4sher`,
  GITHUB_PATH: `token.json`,

  ROLES_FILE: `./database/roles.json`
}