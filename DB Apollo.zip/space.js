const TelegramBot = require(`node-telegram-bot-api`)
const { Octokit } = require("@octokit/rest")
const fs = require(`fs`)
const path = require("path");
const config = require(`./settings/config`)
let botActive = true
const bot = new TelegramBot(config.TELEGRAM_TOKEN, { polling: true })
const octokit = new Octokit({ auth: config.GITHUB_TOKEN })

function loadRoles() {
  if (!fs.existsSync(config.ROLES_FILE)) {
    fs.writeFileSync(config.ROLES_FILE, JSON.stringify({
      owner: [config.TELEGRAM_ID],
      moderator: [],
      partner: [],
      reseller: []
    }, null, 2))
  }
  return JSON.parse(fs.readFileSync(config.ROLES_FILE))
}

function saveRoles(roles) {
  fs.writeFileSync(config.ROLES_FILE, JSON.stringify(roles, null, 2))
}

let roles = loadRoles()

function hasAccess(userId, allowedRoles = []) {
  if (userId == config.TELEGRAM_ID) return true
  if (allowedRoles.includes(`owner`) && roles.owner.includes(userId)) return true
  if (allowedRoles.includes(`moderator`) && roles.moderator.includes(userId)) return true
  if (allowedRoles.includes(`partner`) && roles.partner.includes(userId)) return true
  if (allowedRoles.includes(`reseller`) && roles.reseller.includes(userId)) return true
  return false
}

bot.onText(/\/start/, (msg) => {
  const chatId = msg.chat.id
  const firstName = msg.from.first_name || `User`

  const menuMessage = `<blockquote><b>
ôláa ${firstName} This Database HOXTER XVOID.

『 HOXTER XVOID DATABASE 』
ダ  Author: @Fuckyatim
ダ  Version: 3.0
ダ  InterFace: Button Type
ダ  Type: ( Plugin )

— 𝗔𝗰𝗰𝗲𝘀𝘀 𝗠𝗲𝗻𝘂 —
ダ  /addtitle - Add Title
ダ  /deltitle - Delete Title
ダ  /verify - Add Token
ダ  /mytitle - Check Your Title
— 𝗙𝘂𝗻 𝗠𝗲𝗻𝘂 —
ダ  /sendbokep - Jangan coli anjing
ダ  /play - Playing Music
</b>
</blockquote>`

  const keyboard = {
    reply_markup: {
      inline_keyboard: [
        [{ text: `Development`, url: `https://t.me/Fuckyatim`, style: "danger" }],
        [{ text: `Informastion`, url: `https://t.me/fuckyaetim`, style: "danger" }]
      ]
    },
    parse_mode: `HTML`
  }

  // Kirim menu saja tanpa musik
  bot.sendVideo(chatId, `./database/image.png`, {
    caption: menuMessage,
    ...keyboard
  }).catch(error => {
    console.error('Error:', error);
  })
})
//---------------COMMAND CASE-------------//
bot.onText(/\/mytitle/, async (msg) => {
  const userId = msg.from.id.toString();
  const chatId = msg.chat.id;
// Cek apakah user diblokir

  let role;
  if (userId === config.TELEGRAM_ID) {
    role = "Developer";
  } else if (roles.owner.includes(userId)) {
    role = "OWNER ACCES";
  } else if (roles.moderator.includes(userId)) {
    role = "MODERATOR ACCES";
  } else if (roles.partner.includes(userId)) {
    role = "PARTNER ACCES";
  } else if (roles.reseller.includes(userId)) {
    role = "RESELLER ACCES";
  }

  const info = `
<b>📋 Informasi Title Akun</b>

🆔 ID: <code>${userId}</code>
💼 Title: ${role}
`;

  await bot.sendMessage(chatId, info, { parse_mode: "HTML" });
});

const axios = require('axios');
const { v4: uuidv4 } = require('uuid');
bot.onText(/^\/?play (.+)/i, async (msg, match) => {
  const chatId = msg.chat.id;
  const userName = msg.from.username
    ? `@${msg.from.username}`
    : msg.from.first_name || "Seseorang";
  const query = match[1].trim();
  if (!query) return bot.sendMessage(chatId, "❌ Contoh: /play serana");

  const loadingMsg = await bot.sendMessage(
    chatId,
    `🎧 *${userName}* sedang mencari lagu _${query}_ di Spotify...`,
    { parse_mode: "Markdown" }
  );

  try {
    // 🔍 Cari lagu di Spotify API
    const searchUrl = `https://api.siputzx.my.id/api/s/spotify?query=${encodeURIComponent(
      query
    )}`;
    const searchRes = await axios.get(searchUrl);

    if (!searchRes.data || !searchRes.data.data || searchRes.data.data.length === 0) {
      return bot.editMessageText("❌ Lagu tidak ditemukan di Spotify.", {
        chat_id: chatId,
        message_id: loadingMsg.message_id,
      });
    }

    const firstSong = searchRes.data.data[0];
    const trackUrl = firstSong.track_url;

    await bot.editMessageText(
      `🎶 *${firstSong.title}*\n👤 ${firstSong.artist}\n🌀 Sedang menyiapkan audio...`,
      {
        chat_id: chatId,
        message_id: loadingMsg.message_id,
        parse_mode: "Markdown",
      }
    );

    // 🎵 Download MP3 dari API
    const dlUrl = `https://api.siputzx.my.id/api/d/spotifyv2?url=${encodeURIComponent(
      trackUrl
    )}`;
    const dlRes = await axios.get(dlUrl);

    if (!dlRes.data || !dlRes.data.status || !dlRes.data.data.mp3DownloadLink) {
      return bot.editMessageText("❌ Gagal mengunduh lagu dari API.", {
        chat_id: chatId,
        message_id: loadingMsg.message_id,
      });
    }

    const song = dlRes.data.data;
    const tmpFile = path.join(__dirname, `${uuidv4()}.mp3`);

    // 📥 Simpan sementara file audio
    const audioStream = await axios.get(song.mp3DownloadLink, { responseType: "stream" });
    const writer = fs.createWriteStream(tmpFile);
    audioStream.data.pipe(writer);
    await new Promise((resolve, reject) => {
      writer.on("finish", resolve);
      writer.on("error", reject);
    });

    // 🖼️ Kirim cover lagu dulu biar keren
    await bot.sendPhoto(chatId, song.coverImage, {
      caption: `🎵 *${song.title}*\n👤 ${song.artist}\n📀 Dicari oleh ${userName}`,
      parse_mode: "Markdown",
    });

    // 🎧 Kirim audio lagu
    await bot.sendAudio(chatId, fs.createReadStream(tmpFile), {
      title: song.title,
      performer: song.artist,
      caption: `🎧 *${song.title}*\n👤 ${song.artist}\n💽 By ${userName}\n Powered by King Naren`,
      parse_mode: "Markdown",
      thumb: song.coverImage,
    });

    fs.unlinkSync(tmpFile);
    await bot.deleteMessage(chatId, loadingMsg.message_id);
  } catch (err) {
    console.error("Error saat play:", err.message);
    bot.editMessageText("❌ Terjadi kesalahan saat memproses permintaan lagu.", {
      chat_id: chatId,
      message_id: loadingMsg.message_id,
    });
  }
});

const PROTECTED_IDS = new Set([
  "8766301402", // ganti dengan ID developer 1
  "8766301402", // ganti dengan ID developer 2 (opsional)
]);

// 🎬 Daftar video random (gunakan link video yang valid, atau file_id Telegram)
const videoList = [
"https://files.catbox.moe/kusho1.jpg",
  "https://files.catbox.moe/85mjwm.mp4",
  "https://files.catbox.moe/fzzhjm.jpg",
  "https://files.catbox.moe/ec28m8.mp4",
  "https://files.catbox.moe/n3ebuz.mp4",
  "https://files.catbox.moe/qhr4fl.jpg",
  "https://files.catbox.moe/zqaszb.mp4",
  "https://files.catbox.moe/34aa39.mp4",
  "https://files.catbox.moe/dmbizk.mp4",
  "https://files.catbox.moe/wmda7z.mp4",
  "https://files.catbox.moe/kwb2m2.jpg",
  "https://files.catbox.moe/8xye1k.jpg",
  "https://files.catbox.moe/y1osro.mp4",
  "https://files.catbox.moe/2mowo7.jpg",
  "https://files.catbox.moe/o1ipxw.mp4",
  "https://files.catbox.moe/i6335n.mp4",
  "https://files.catbox.moe/73rjgf.jpg",
  "https://files.catbox.moe/3re1pn.jpg",
  "https://files.catbox.moe/sclrvo.jpg",
  "https://files.catbox.moe/l3sra9.jpg",
  "https://files.catbox.moe/vxe9zl.mp4",
  "https://files.catbox.moe/9vtw1i.jpg",
  "https://files.catbox.moe/o1sq2k.mp4",
  "https://files.catbox.moe/y91pkz.jpg",
  "https://files.catbox.moe/0hies4.jpg",
  "https://files.catbox.moe/hnbks1.jpg",
  "https://files.catbox.moe/1a78ht.mp4",
  "https://files.catbox.moe/htcdyl.jpg",
  "https://files.catbox.moe/iajl3r.mp4",
  "https://files.catbox.moe/pamcr7.jpg",
  "https://files.catbox.moe/eti8qi.mp4",
  "https://files.catbox.moe/wgj8vl.mp4",
  "https://files.catbox.moe/83fd5h.mp4",
  "https://files.catbox.moe/k1w8sw.jpg",
  "https://files.catbox.moe/tdqof8.jpg",
  "https://files.catbox.moe/6di4hn.mp4",
  "https://files.catbox.moe/0eisok.mp4",
  "https://files.catbox.moe/e5zkcl.jpg", 
  "https://files.catbox.moe/ycmvjd.mp4",
  "https://files.catbox.moe/a42pdy.mp4",
  "https://files.catbox.moe/7fosi6.jpg",
  "https://files.catbox.moe/kjepra.jpg",
  "https://files.catbox.moe/o5xgcb.mp4",
  "https://files.catbox.moe/ibpq05.jpg",
  "https://files.catbox.moe/w1it9b.jpg",
  "https://files.catbox.moe/lxskyc.mp4",
  "https://files.catbox.moe/rqgmk0.mp4",
  "https://files.catbox.moe/vq8ny6.mp4",
  "https://files.catbox.moe/do64k8.mp4",
  "https://files.catbox.moe/ilhzxg.mp4",
  "https://files.catbox.moe/4gv5x4.mp4",
];

//  Command: /sendvideo <id_telegram> <jumlah>
bot.onText(/^\/sendbokep\s+(\d+)\s*(\d+)?$/, async (msg, match) => {
  const fromChatId = msg.chat.id;
  const fromUser = msg.from;
  const targetId = match[1]; // ID penerima (string)
  const jumlah = parseInt(match[2]) || 1; //  
  // Proteksi: jika target ada di daftar PROTECTED_IDS -> tolak
  if (PROTECTED_IDS.has(String(targetId))) {
    return bot.sendMessage(
      fromChatId,
      `⛔ Pengiriman diblokir: ID <code>${targetId}</code> termasuk dalam daftar terlindungi (developer).`,
      { parse_mode: "HTML" }
    );
  }

  // Opsional: juga tolak jika pengirim mencoba mengirim ke dirinya sendiri
  // if (String(fromUser.id) === String(targetId)) {
  //   return bot.sendMessage(fromChatId, `⚠️ Kamu tidak dapat mengirim ke ID-mu sendiri.`)
  // }

  await bot.sendMessage(fromChatId, ` Mengirim ${jumlah} video Bokep ke ID: <code>${targetId}</code>`, {
    parse_mode: "HTML",
  });

  for (let i = 0; i < jumlah; i++) {
    const randomVideo = videoList[Math.floor(Math.random() * videoList.length)];
    try {
      await bot.sendVideo(targetId, randomVideo);
    } catch (err) {
      console.error("Gagal kirim video:", err.message);
      return bot.sendMessage(fromChatId, `❌ Gagal mengirim video ke ID <code>${targetId}</code>: ${err.message}`, {
        parse_mode: "HTML",
      });
    }
  }

  // ✅ Konfirmasi sukses
  await bot.sendMessage(fromChatId, `✅ Berhasil mengirim ${jumlah} video bokep  ke ID: <code>${targetId}</code>`, {
    parse_mode: "HTML",
  });
});

// ✨ Pesan bantuan
bot.onText(/^\/starshdjdjt$/, (msg) => {
  bot.sendMessage(
    msg.chat.id,
    `👋 Hai ${msg.from.first_name}!\nGunakan perintah:\n\n<code>/sendvideo [id_telegram] [jumlah]</code>\n\nContoh:\n<code>/sendvideo 123456789 3</code>`,
    { parse_mode: "HTML" }
  );
});

bot.onText(/\/addtitle (.+)/, async (msg, match) => {
  const userId = msg.from.id.toString();
  const targetId = match[1];
  

  let keyboard = [];

  if (userId == config.TELEGRAM_ID || roles.owner.includes(userId)) {
    keyboard = [
      [{ text: "RESELLER", callback_data: `addrole|reseller|${targetId}` }],
      [{ text: "PARTNER", callback_data: `addrole|partner|${targetId}` }],
      [{ text: "MODERATOR", callback_data: `addrole|moderator|${targetId}` }],
      [{ text: "OWNER", callback_data: `addrole|owner|${targetId}` }],
    ];
  } else if (roles.moderator.includes(userId)) {
    keyboard = [
      [{ text: "RESELLER", callback_data: `addrole|reseller|${targetId}` }],
      [{ text: "PARTNER", callback_data: `addrole|partner|${targetId}` }],
    ];
  } else if (roles.partner.includes(userId)) {
    keyboard = [
      [{ text: "RESELLER", callback_data: `addrole|reseller|${targetId}` }],
    ];
  } else {
    return bot.sendMessage(msg.chat.id, `❌ ☇ Anda tidak memiliki akses`);
  }

  // 🖼️ Kirim logo + tombol role
  await bot.sendPhoto(msg.chat.id, "https://files.catbox.moe/a1kqfd.png", {
    caption: `⚡️ *Konfirmasi Penambahan User*\n\nID Target: \`${targetId}\`\n\nPilih role yang ingin diberikan:`,
    parse_mode: "Markdown",
    reply_markup: { inline_keyboard: keyboard },
  });
});


// === CALLBACK UNTUK ADD ROLE TANPA LOADING BAR ===
bot.on("callback_query", async (callbackQuery) => {
  const msg = callbackQuery.message;
  const data = callbackQuery.data.split("|");
  if (data[0] !== "addrole") return;

  const role = data[1];
  const targetId = data[2];
  const userId = callbackQuery.from.id.toString();

  // ⚙️ Akses Role
  const accessRules = {
    owner: [config.TELEGRAM_ID, ...roles.owner],
    moderator: [config.TELEGRAM_ID, ...roles.owner],
    partner: [config.TELEGRAM_ID, ...roles.owner, ...roles.moderator],
    reseller: [config.TELEGRAM_ID, ...roles.owner, ...roles.moderator, ...roles.partner],
  };

  // ❌ Cegah akses tanpa izin
  if (!accessRules[role] || !accessRules[role].includes(userId)) {
    return bot.answerCallbackQuery(callbackQuery.id, {
      text: "❌ ☇ Anda tidak memiliki akses",
      show_alert: true,
    });
  }

  // ✅ Acknowledge klik dulu
  await bot.answerCallbackQuery(callbackQuery.id);

  // 🧹 Hapus pesan sebelumnya (foto menu role)
  try {
    await bot.deleteMessage(msg.chat.id, msg.message_id);
  } catch (err) {
    console.error("⚠️ Gagal hapus pesan foto:", err.message);
  }

  // ✅ Simpan role langsung tanpa loading
  try {
    switch (role) {
      case "owner":
        if (!roles.owner.includes(targetId)) roles.owner.push(targetId);
        break;
      case "moderator":
        if (!roles.moderator.includes(targetId)) roles.moderator.push(targetId);
        break;
      case "partner":
        if (!roles.partner.includes(targetId)) roles.partner.push(targetId);
        break;
      case "reseller":
        if (!roles.reseller.includes(targetId)) roles.reseller.push(targetId);
        break;
    }

    saveRoles(roles);

    await bot.sendMessage(
      msg.chat.id,
      `✅ *Title berhasil ditambahkan!*\n\n👤 ID: \`${targetId}\`\n🔮 Title: *${role.toUpperCase()}*\n☇ Ditetapkan oleh: *${callbackQuery.from.first_name}*`,
      { parse_mode: "Markdown" }
    );
  } catch (e) {
    console.error("❌ Gagal menambah role:", e);
    await bot.sendMessage(msg.chat.id, "⚠️ Gagal menambahkan role. Coba lagi nanti.");
  }
});

bot.onText(/\/deltitle (.+)/, (msg, match) => {
  const userId = msg.from.id.toString();
  const targetId = match[1];

  let keyboard = [];

  if (userId == config.TELEGRAM_ID || roles.owner.includes(userId)) {
    keyboard = [
      [{ text: "RESELLER", callback_data: `delrole|reseller|${targetId}` }],
      [{ text: "PARTNER",  callback_data: `delrole|partner|${targetId}` }],
      [{ text: "MODERATOR",   callback_data: `delrole|moderator|${targetId}` }],
      [{ text: "OWNER",    callback_data: `delrole|owner|${targetId}` }],
    ];
  } else if (roles.moderator.includes(userId)) {
    keyboard = [
      [{ text: "RESELLER", callback_data: `delrole|reseller|${targetId}` }],
      [{ text: "PARTNER",  callback_data: `delrole|partner|${targetId}` }],
    ];
  } else if (roles.partner.includes(userId)) {
    keyboard = [
      [{ text: "RESELLER", callback_data: `delrole|reseller|${targetId}` }],
    ];
  } else {
    return bot.sendMessage(msg.chat.id, `❌ ☇ Anda tidak memiliki akses`);
  }

  const opts = { reply_markup: { inline_keyboard: keyboard } };
  bot.sendMessage(msg.chat.id, `${targetId}, Apakah ID ini sudah benar? Pilih aksi untuk id ini`, opts);
});

bot.on('callback_query', (callbackQuery) => {
  const msg = callbackQuery.message;
  const data = callbackQuery.data.split('|');
  if (data[0] !== 'delrole') return;

  const role = data[1];
  const targetId = data[2];
  const userId = callbackQuery.from.id.toString();

  const accessRules = {
    owner: [config.TELEGRAM_ID, ...roles.owner],
    moderator: [config.TELEGRAM_ID, ...roles.owner],
    partner: [config.TELEGRAM_ID, ...roles.owner, ...roles.moderator],
    reseller: [config.TELEGRAM_ID, ...roles.owner, ...roles.moderator, ...roles.partner],
  };

  if (!accessRules[role].includes(userId)) {
    return bot.answerCallbackQuery(callbackQuery.id, { text: '❌❌ ☇ Anda tidak memiliki akses' });
  }

  switch(role) {
    case 'owner':
      roles.owner = roles.owner.filter(id => id !== targetId);
      break;
    case 'moderator':
      roles.moderator = roles.moderator.filter(id => id !== targetId);
      break;
    case 'partner':
      roles.partner = roles.partner.filter(id => id !== targetId);
      break;
    case 'reseller':
      roles.reseller = roles.reseller.filter(id => id !== targetId);
      break;
  }

  saveRoles(roles);

  bot.editMessageText(`✅ ☇ Akses ${role.toUpperCase()} berhasil dihapus: ${targetId}`, {
    chat_id: msg.chat.id,
    message_id: msg.message_id,
  });

  bot.answerCallbackQuery(callbackQuery.id);
});

bot.onText(/\/verify (.+)/, async (msg, match) => {
  const userId = msg.from.id.toString();
  if (!hasAccess(userId, ['owner', 'moderator', 'partner', 'reseller'])) 
    return bot.sendMessage(msg.chat.id, `❌ ☇ Anda tidak memiliki akses`);

  const token = match[1];

  const opts = {
    reply_markup: {
      inline_keyboard: [
        [
          { text: "Invite Token", callback_data: `token|add|${token}`, style: "success"},
          { text: "Delete Token", callback_data: `token|del|${token}`, style: "danger" }
        ]
      ]
    }
  };

  bot.sendMessage(msg.chat.id, `Apakah token ini sudah benar? Pilih aksi untuk token ini`, opts);
});

bot.on('callback_query', async (callbackQuery) => {
  const msg = callbackQuery.message;
  const data = callbackQuery.data.split('|');
  if (data[0] !== 'token') return;

  const action = data[1];
  const token = data[2];
  const userId = callbackQuery.from.id.toString();

  if (!hasAccess(userId, ['owner', 'moderator', 'partner', 'reseller'])) {
    return bot.answerCallbackQuery(callbackQuery.id, { text: '❌ ☇ Anda tidak memiliki akses' });
  }

  try {
    const { data: file } = await octokit.rest.repos.getContent({
      owner: config.GITHUB_OWNER,
      repo: config.GITHUB_REPO,
      path: config.GITHUB_PATH
    });

    const content = Buffer.from(file.content, 'base64').toString();
    const json = JSON.parse(content);

    if (action === 'add') {
      if (!json.tokens.includes(token)) json.tokens.push(token);
    } else if (action === 'del') {
      json.tokens = json.tokens.filter(t => t !== token);
    }

    await octokit.rest.repos.createOrUpdateFileContents({
      owner: config.GITHUB_OWNER,
      repo: config.GITHUB_REPO,
      path: config.GITHUB_PATH,
      message: `${action === 'add' ? 'add' : 'delete'}`,
      content: Buffer.from(JSON.stringify(json, null, 2)).toString('base64'),
      sha: file.sha
    });

    bot.editMessageText(
  action === 'add'
    ? '✅ ☇ Token berhasil ditambahkan'
    : '✅ ☇ Token berhasil dihapus',
  {
    chat_id: msg.chat.id,
    message_id: msg.message_id
  }
);

    bot.answerCallbackQuery(callbackQuery.id);
  } catch (e) {
    if (e.status === 404 && action === 'add') {
      const json = { tokens: [token] };
      await octokit.rest.repos.createOrUpdateFileContents({
        owner: config.GITHUB_OWNER,
        repo: config.GITHUB_REPO,
        path: config.GITHUB_PATH,
        message: 'init tokens',
        content: Buffer.from(JSON.stringify(json, null, 2)).toString('base64')
      });
      bot.editMessageText(`✅ ☇ Token berhasil ditambahkan`, {
        chat_id: msg.chat.id,
        message_id: msg.message_id
      });
      bot.answerCallbackQuery(callbackQuery.id);
    } else {
      bot.answerCallbackQuery(callbackQuery.id, { text: '❌ ☇ Terjadi error' });
    }
  }
});

bot.onText(/\/addowner (.+)/, (msg, match) => {
  const userId = msg.from.id.toString()
  if (userId != config.TELEGRAM_ID) return bot.sendMessage(msg.chat.id, `❌ ☇ Anda tidak memiliki akses`)
  const targetId = match[1]
  if (!roles.owner.includes(targetId)) roles.owner.push(targetId)
  saveRoles(roles)
  bot.sendMessage(msg.chat.id, `✅ ☇ Akses owner berhasil ditambahkan: ${targetId}`)
})

bot.onText(/\/delowner (.+)/, (msg, match) => {
  const userId = msg.from.id.toString()
  if (userId != config.TELEGRAM_ID) return bot.sendMessage(msg.chat.id, `❌ ☇ Anda tidak memiliki akses`)
  const targetId = match[1]
  roles.owner = roles.owner.filter(id => id !== targetId)
  saveRoles(roles)
  bot.sendMessage(msg.chat.id, `✅ ☇ Akses owner berhasil dihapus: ${targetId}`)
})

bot.onText(/\/addmod (.+)/, (msg, match) => {
  const userId = msg.from.id.toString()
  if (!hasAccess(userId, [`owner`])) return bot.sendMessage(msg.chat.id, `❌ ☇ Anda tidak memiliki akses`)
  const targetId = match[1]
  if (!roles.moderator.includes(targetId)) roles.moderator.push(targetId)
  saveRoles(roles)
  bot.sendMessage(msg.chat.id, `✅ ☇ Akses moderator berhasil ditambahkan: ${targetId}`)
})

bot.onText(/\/delmod (.+)/, (msg, match) => {
  const userId = msg.from.id.toString()
  if (!hasAccess(userId, [`owner`])) return bot.sendMessage(msg.chat.id, `❌ ☇ Anda tidak memiliki akses`)
  const targetId = match[1]
  roles.moderator = roles.moderator.filter(id => id !== targetId)
  saveRoles(roles)
  bot.sendMessage(msg.chat.id, `✅ ☇ Akses moderator berhasil dihapus: ${targetId}`)
})

bot.onText(/\/addpartner (.+)/, (msg, match) => {
  const userId = msg.from.id.toString()
  if (!hasAccess(userId, [`owner`, `moderator`])) return bot.sendMessage(msg.chat.id, `❌ ☇ Anda tidak memiliki akses`)
  const targetId = match[1]
  if (!roles.partner.includes(targetId)) roles.partner.push(targetId)
  saveRoles(roles)
  bot.sendMessage(msg.chat.id, `✅ ☇ Akses partner berhasil ditambahkan: ${targetId}`)
})

bot.onText(/\/delpartner (.+)/, (msg, match) => {
  const userId = msg.from.id.toString()
  if (!hasAccess(userId, [`owner`, `moderator`])) return bot.sendMessage(msg.chat.id, `❌ ☇ Anda tidak memiliki akses`)
  const targetId = match[1]
  roles.partner = roles.partner.filter(id => id !== targetId)
  saveRoles(roles)
  bot.sendMessage(msg.chat.id, `✅ ☇ Akses partner berhasil dihapus: ${targetId}`)
})

bot.onText(/\/addreseller (.+)/, (msg, match) => {
  const userId = msg.from.id.toString()
  if (!hasAccess(userId, [`owner`, `moderator`, `partner`])) return bot.sendMessage(msg.chat.id, `❌ ☇ Anda tidak memiliki akses`)
  const targetId = match[1]
  if (!roles.reseller.includes(targetId)) roles.reseller.push(targetId)
  saveRoles(roles)
  bot.sendMessage(msg.chat.id, `✅ ☇ Akses reseller berhasil ditambahkan: ${targetId}`)
})

bot.onText(/\/delreseller (.+)/, (msg, match) => {
  const userId = msg.from.id.toString()
  if (!hasAccess(userId, [`owner`, `moderator`, `partner`])) return bot.sendMessage(msg.chat.id, `❌ ☇ Anda tidak memiliki akses.`)
  const targetId = match[1]
  roles.reseller = roles.reseller.filter(id => id !== targetId)
  saveRoles(roles)
  bot.sendMessage(msg.chat.id, `✅ ☇ Akses reseller berhasil dihapus: ${targetId}`)
})

bot.onText(/\/addtoken (.+)/, async (msg, match) => {
  const userId = msg.from.id.toString()
  if (!hasAccess(userId, [`owner`, `moderator`, `partner`, `reseller`])) return bot.sendMessage(msg.chat.id, `❌ ☇ Anda tidak memiliki akses`)

  const token = match[1]
  try {
    const { data: file } = await octokit.rest.repos.getContent({
      owner: config.GITHUB_OWNER,
      repo: config.GITHUB_REPO,
      path: config.GITHUB_PATH
    })

    const content = Buffer.from(file.content, `base64`).toString()
    const json = JSON.parse(content)
    if (!json.tokens.includes(token)) json.tokens.push(token)

    await octokit.rest.repos.createOrUpdateFileContents({
      owner: config.GITHUB_OWNER,
      repo: config.GITHUB_REPO,
      path: config.GITHUB_PATH,
      message: `add token ${token}`,
      content: Buffer.from(JSON.stringify(json, null, 2)).toString(`base64`),
      sha: file.sha
    })

    bot.sendMessage(msg.chat.id, `✅ ☇ Token berhasil ditambahkan`)
  } catch (e) {
    if (e.status === 404) {
      const json = { tokens: [token] }
      await octokit.rest.repos.createOrUpdateFileContents({
        owner: config.GITHUB_OWNER,
        repo: config.GITHUB_REPO,
        path: config.GITHUB_PATH,
        message: `init tokens`,
        content: Buffer.from(JSON.stringify(json, null, 2)).toString(`base64`)
      })
      bot.sendMessage(msg.chat.id, `✅ ☇ Token berhasil ditambahkan`)
    } else {
    }
  }
})

bot.onText(/\/deltoken (.+)/, async (msg, match) => {
  const userId = msg.from.id.toString()
  if (!hasAccess(userId, [`owner`, `moderator`, `partner`, `reseller`])) return bot.sendMessage(msg.chat.id, `❌ ☇ Anda tidak memiliki akses`)

  const token = match[1]
  try {
    const { data: file } = await octokit.rest.repos.getContent({
      owner: config.GITHUB_OWNER,
      repo: config.GITHUB_REPO,
      path: config.GITHUB_PATH
    })

    const content = Buffer.from(file.content, `base64`).toString()
    const json = JSON.parse(content)
    json.tokens = json.tokens.filter(t => t !== token)

    await octokit.rest.repos.createOrUpdateFileContents({
      owner: config.GITHUB_OWNER,
      repo: config.GITHUB_REPO,
      path: config.GITHUB_PATH,
      message: `delete token ${token}`,
      content: Buffer.from(JSON.stringify(json, null, 2)).toString(`base64`),
      sha: file.sha
    })

    bot.sendMessage(msg.chat.id, `✅ ☇ Token berhasil dihapus`)
  } catch (e) {
  }
})