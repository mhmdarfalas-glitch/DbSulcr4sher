module.exports = {
  TELEGRAM_TOKEN: `8641778781:AAH3Q7vLCZ1Lv1IvG_IEQPzuVwOQAnGW2lE`,
  TELEGRAM_ID: `8766301402`,

  GITHUB_TOKEN: `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`,
  GITHUB_OWNER: `abilhrdiana23-design`,
  GITHUB_REPO: `mpruy`,
  GITHUB_PATH: `token.json`,

  ROLES_FILE: `./database/roles.json`
}